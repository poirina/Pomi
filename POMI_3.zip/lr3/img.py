from PyQt5 import QtCore, QtGui, QtWidgets
from PIL import Image, ImageDraw
from ui import Ui_Dialog
import numpy as np
import sys
import cv2



app = QtWidgets.QApplication(sys.argv)
Dialog = QtWidgets.QDialog()
ui = Ui_Dialog()
ui.setupUi(Dialog)
Dialog.show()

path = 'default.jpg'
step = 20

# ui.label.setPixmap(QtGui.QPixmap(path))


def load():
    global path
    path = QtWidgets.QFileDialog.getOpenFileName()[0]
    ui.label.setPixmap(QtGui.QPixmap(path))
    img = Image.open(path)
    img.save('result.jpg')
    img.save('default.jpg')
    ui.label.setScaledContents(True)




def toGray():
    img = Image.open('result.jpg')
    pix = img.load()
    width = img.size[0]
    height = img.size[1]
    draw = ImageDraw.Draw(img)
    for i in range(width):
        for j in range(height):
            a = pix[i, j][0]
            b = pix[i, j][1]
            c = pix[i, j][2]
            S = (a + b + c) // 3
            draw.point((i, j), (S, S, S))
    img.save('result.jpg', 'JPEG')
    ui.label.setScaledContents(True)
    ui.label.setPixmap(QtGui.QPixmap('result.jpg'))



def scale():
    img = Image.open('result.jpg')
    winp = QtWidgets.QInputDialog()
    width = winp.getInt(Dialog, ' ', 'Input height')
    hinp = QtWidgets.QInputDialog()
    height = hinp.getInt(Dialog, ' ', 'Input width')
    maxsize = (width[0], height[0])
    print(maxsize)
    img.thumbnail(maxsize, Image.ANTIALIAS)
    img.save('result.jpg', 'JPEG')
    ui.label.setScaledContents(False)
    ui.label.setPixmap(QtGui.QPixmap('result.jpg'))


def setStep():
    global step
    inp = QtWidgets.QInputDialog()
    step = inp.getInt(Dialog, ' ', 'Input step')[0]



def moveRight():
    M = np.float32([[1, 0, step], [0, 1, 0]])
    img = cv2.imread('result.jpg')
    (rows, cols) = img.shape[:2]
    res = cv2.warpAffine(img, M, (cols, rows))
    cv2.imwrite('result.jpg', res)
    ui.label.setPixmap(QtGui.QPixmap('result.jpg'))

def moveLeft():
    M = np.float32([[1, 0, -step], [0, 1, 0]])
    img = cv2.imread('result.jpg')
    (rows, cols) = img.shape[:2]
    res = cv2.warpAffine(img, M, (cols, rows))
    cv2.imwrite('result.jpg', res)
    ui.label.setPixmap(QtGui.QPixmap('result.jpg'))


def moveUp():
    M = np.float32([[1, 0, 0], [0, 1, -step]])
    img = cv2.imread('result.jpg')
    (rows, cols) = img.shape[:2]
    res = cv2.warpAffine(img, M, (cols, rows))
    cv2.imwrite('result.jpg', res)
    ui.label.setPixmap(QtGui.QPixmap('result.jpg'))


def moveDown():
    M = np.float32([[1, 0, 0], [0, 1, step]])
    img = cv2.imread('result.jpg')
    (rows, cols) = img.shape[:2]
    res = cv2.warpAffine(img, M, (cols, rows))
    cv2.imwrite('result.jpg', res)
    ui.label.setPixmap(QtGui.QPixmap('result.jpg'))


def rotate():
    dialog = QtWidgets.QInputDialog()
    angle = dialog.getInt(Dialog, ' ', "Input angle")
    img = Image.open('result.jpg')
    img = img.rotate(angle[0], expand=True)
    img.save('result.jpg', 'JPEG')
    ui.label.setPixmap(QtGui.QPixmap('result.jpg'))


def reset():
    ui.label.setScaledContents(True)
    ui.label.resize(500, 300)
    ui.label.setPixmap(QtGui.QPixmap('default.jpg'))
    img = Image.open('default.jpg')
    img.save('result.jpg')

def toR():
    img = Image.open('result.jpg')
    pix = img.load()
    width = img.size[0]
    height = img.size[1]
    draw = ImageDraw.Draw(img)
    for i in range(width):
        for j in range(height):
            r = pix[i, j][0]
            draw.point((i, j), (r, 0, 0))
    img.save('r.jpg', 'JPEG')
    ui.label.setScaledContents(True)
    ui.label.setPixmap(QtGui.QPixmap('r.jpg'))


def toG():
    img = Image.open('result.jpg')
    pix = img.load()
    width = img.size[0]
    height = img.size[1]
    draw = ImageDraw.Draw(img)
    for i in range(width):
        for j in range(height):
            g = pix[i, j][1]
            draw.point((i, j), (0, g, 0))
    img.save('g.jpg', 'JPEG')
    ui.label.setScaledContents(True)
    ui.label.setPixmap(QtGui.QPixmap('g.jpg'))


def toB():
    img = Image.open('result.jpg')
    pix = img.load()
    width = img.size[0]
    height = img.size[1]
    draw = ImageDraw.Draw(img)
    for i in range(width):
        for j in range(height):
            b = pix[i, j][2]
            draw.point((i, j), (0, 0, b))
    img.save('b.jpg', 'JPEG')
    ui.label.setScaledContents(True)
    ui.label.setPixmap(QtGui.QPixmap('b.jpg'))


def save():
    a = QtWidgets.QFileDialog.getSaveFileName(None, '', '', 'jpeg (*.jpg)')
    img = Image.open('result.jpg')
    img.save(a[0])


def saveR():
    a = QtWidgets.QFileDialog.getSaveFileName(None, '', '', 'jpeg (*.jpg)')
    img = Image.open('r.jpg')
    img.save(a[0])


def saveG():
    a = QtWidgets.QFileDialog.getSaveFileName(None, '', '', 'jpeg (*.jpg)')
    img = Image.open('g.jpg')
    img.save(a[0])


def saveB():
    a = QtWidgets.QFileDialog.getSaveFileName(None, '', '', 'jpeg (*.jpg)')
    img = Image.open('b.jpg')
    img.save(a[0])


ui.saver.clicked.connect(saveR)
ui.saveg.clicked.connect(saveG)
ui.saveb.clicked.connect(saveB)
ui.setstep.clicked.connect(setStep)
ui.save.clicked.connect(save)
ui.r.clicked.connect(toR)
ui.g.clicked.connect(toG)
ui.b.clicked.connect(toB)
ui.reset.clicked.connect(reset)
ui.rotate.clicked.connect(rotate)
ui.moveleft.clicked.connect(moveLeft)
ui.moveright.clicked.connect(moveRight)
ui.movedown.clicked.connect(moveDown)
ui.moveup.clicked.connect(moveUp)
ui.scale.clicked.connect(scale)
ui.loadFile.clicked.connect(load)
ui.convert.clicked.connect(toGray)
sys.exit(app.exec_())